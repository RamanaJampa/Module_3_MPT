package com.cg.Exception;

public class CustomException extends Exception{
	
	public static final String MESSAGE1 = "internal error. Try later!!";
	
	
	public CustomException(String message) {
		super(message);
		
	}

}
