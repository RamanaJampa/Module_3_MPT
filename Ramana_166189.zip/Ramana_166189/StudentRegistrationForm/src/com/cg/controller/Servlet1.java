package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.Exception.CustomException;
import com.cg.StudentBean.StudentBean;


@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StudentBean studentBean=new StudentBean();
		
		studentBean.setStu_name(request.getParameter("student_name"));
		studentBean.setStu_dept(request.getParameter("dept_name"));
		studentBean.setMarks(request.getParameter("marks"));
		studentBean.setNumber(request.getParameter("mob_number"));
		studentBean.setPercent(request.getParameter("percent"));
		
		request.setAttribute("name", studentBean.getStu_name());
		request.setAttribute("dept_name",studentBean.getStu_dept());
		request.setAttribute("marks",studentBean.getMarks());
		request.setAttribute("number",studentBean.getNumber());
		request.setAttribute("percent",studentBean.getPercent());
		
		try
		{
			HttpSession session=request.getSession();
			
			if(session.isNew())
			{
				session.setAttribute("stu_bean",studentBean);
			}
			else
			{
				throw new CustomException("Session Creation error");
			}
			
		}
		catch(CustomException CE)
		{
			System.out.println("Session Creation Error");
		}
				/*PrintWriter p= response.getWriter();
				
				p.print(studentBean.getStu_name());
				p.println(studentBean.getStu_dept());
				p.println(studentBean.getMarks());
				p.println(studentBean.getNumber());
				p.println(studentBean.getPercent());
				
			*/
				//request.setAttribute("bean", studentBean);
				//request.getRequestDispatcher("home.jsp").include(request, response);
				
				response.sendRedirect("Success.html");
				
	}

}
