package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="distance_cal")
public class DistanceBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String source;
	private String destination;
	private int distancekm;
	private int distancem;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getDistancekm() {
		return distancekm;
	}
	public void setDistancekm(int distancekm) {
		this.distancekm = distancekm;
	}
	public int getDistancem() {
		return distancem;
	}
	public void setDistancem(int distancem) {
		this.distancem = distancem;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	

}
