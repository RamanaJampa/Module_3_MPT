package com.cg.bean;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class InsertValues {
	
public static void main(String[] args) {
		
		DistanceBean dist_Bean=new DistanceBean();
		
		EntityManagerFactory factory = 
				Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Distance ID");
		dist_Bean.setId(scanner.nextInt());
		System.out.println("Enter source");
		dist_Bean.setSource(scanner.next());
		System.out.println("Enter Destination");
		dist_Bean.setDestination(scanner.next());
		System.out.println("Enter Distance in KM");
		dist_Bean.setDistancekm(scanner.nextInt());
		System.out.println("Enter Distance in Meters");
		int metres=scanner.nextInt();
		
		dist_Bean.setDistancem(metres*dist_Bean.getDistancekm());
		
		em.getTransaction().begin();
		
		em.persist(dist_Bean);
		
		em.getTransaction().commit();
		System.out.println("Added one student to database.");
		em.close();
		factory.close();
		
	
	}

}
